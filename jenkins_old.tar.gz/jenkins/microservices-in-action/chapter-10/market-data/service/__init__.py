from flask import Flask
app = Flask('service')

import service.health
