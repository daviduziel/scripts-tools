import os

forwarded_allow_ips = '*'
worker_class = 'gevent'
bind = '0.0.0.0'
loglevel = 'debug'
