A microservice chassis for Python services
==========================================

This project aims to abstract common concerns such as logging, error reporting,
metrics collection, circuit breaking, service registration etc.

----
